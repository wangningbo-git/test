package main.java.com.Zhao.service;

import main.java.com.Zhao.dao.domain.AdminImp;
import main.java.com.Zhao.dao.domain.CompanyInfoImp;
import main.java.com.Zhao.dao.domain.UserInfoImp;
import main.java.com.Zhao.dao.entity.CompanyInfo;
import main.java.com.Zhao.dao.entity.UserInfo;
import main.java.com.Zhao.dao.mapper.AdminMapper;
import main.java.com.Zhao.dao.mapper.CompanyInfoMapper;
import main.java.com.Zhao.dao.mapper.UserInfoMapper;

public class DBService {        //dao 调用

    /**
     * 查询账号，密码是否正确
     * @param account   账号
     * @param password  密码
     * @param role  角色
     * @return  正确返回主键，错误返回NULL
     */
    public String findAccount(String account,String password,String role){
        String str;
        if(role.equals("普通用户")){
            UserInfoMapper userInfoMapper=new UserInfoImp();
            str=userInfoMapper.findByAccount(account,password);
        }else if (role.equals("企业用户")){
            CompanyInfoMapper companyInfoMapper=new CompanyInfoImp();
            str=companyInfoMapper.findByAccount(account,password);
        }else{
            AdminMapper adminMapper=new AdminImp();
            str=adminMapper.findByAdminName(account,password);
        }
        return str;
    }

    /**
     * 插入普通用户信息
     * @param user
     */
    public void insertUser(UserInfo user){
        UserInfoMapper userInfoMapper=new UserInfoImp();
        userInfoMapper.insertUser(user);
    }

    /**
     * 插入公司信息
     * @param company
     */
    public void insertCompany(CompanyInfo company){
        CompanyInfoMapper companyInfoMapper=new CompanyInfoImp();
        companyInfoMapper.insertCompanyInfo(company);
    }

}
