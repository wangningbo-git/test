package main.java.com.Zhao.service;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * 创建验证图片BufferedImage类
 */
public class CreateVailDataCode {
    private BufferedImage image;
    private String str;
    private static char code[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();

    public BufferedImage getImage() {
        return image;
    }

    public String getStr() {
        return str;
    }

    /**
     *产生随机验证码图片，并保存至BufferedImage中，验证码保存至str中
     */
    public void init(){
        int width=60,height=20;
        BufferedImage image=new BufferedImage(width,height,BufferedImage.TYPE_INT_RGB);     //缓冲区图像
        Graphics2D g=(Graphics2D) image.getGraphics();     //绘图对象
        Random random=new Random();
        g.setColor(getRandColor(200,250));     //设置一种随机颜色
        g.fillRect(0, 0, width, height);    //填充背景色
        g.setFont(new Font("Times New Roman", Font.PLAIN, 20));    //设置字体

        String sRand="";
        for(int i=0;i<4;i++){       //随机验证码
            String rand = String.valueOf(code[random.nextInt(code.length)]);
            sRand += rand;
            g.setColor(new Color(20 + random.nextInt(110), 20 + random.nextInt(110), 20 + random.nextInt(110)));
            int degree=random.nextInt()%30; //设置旋转的角度小于30度
            g.rotate(degree*Math.PI/180,13 * i + 6,16);   //正向旋转,(x,y)圆心
            g.drawString(rand, 13 * i + 6, 16);
            g.rotate(-degree*Math.PI/180,13 * i + 6,16);  //方向旋转
        }

        for(int i=0;i<20;i++){       //设置噪点
            int x=random.nextInt(width);
            int y=random.nextInt(height);
            g.setColor(getRandColor(0,255));
            g.fillRect(x,y,2,2);
        }

        this.str=sRand;
        g.dispose();
        this.image=image;
    }

    /**
     *产生随机的颜色
     * @param fc 控制三原色的取值
     * @param bc 控制三原色的取值
     * @return  Color对象
     */
    private Color getRandColor(int fc,int bc) {
        Random random = new Random();
        if(fc>255)fc=255;       //三原色，红绿蓝分量取值介于0-255之间
        if(bc>255)bc=255;
        int r = fc + random.nextInt(bc - fc);
        int g = fc + random.nextInt(bc - fc);
        int b = fc + random.nextInt(bc - fc);
        Color color=new Color(r,g,b);
        return color;
    }
}
