package main.java.com.Zhao.service;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;

public class EmailUnit {
    private static String from="2501059603@qq.com";        //发件人
    private static String host="smtp.qq.com";           //邮件服务器
    private static String subject="人上人招聘网验证码";         //邮件主题
    private static char code[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();


    private String vailDataCode;         //随机验证码
    private String receiveMailAccount;  //收件人账号

    public String getVailDataCode() {
        return vailDataCode;
    }

    public String getReceiveMailAccount() {
        return receiveMailAccount;
    }

    public void setReceiveMailAccount(String receiveMailAccount) {
        this.receiveMailAccount = receiveMailAccount;
    }

    /**
     * 生成随机验证码并拼接成邮件文本内容
     * @return
     */
    public String setText(){
        Random random=new Random();
        vailDataCode="";
        for(int i=0;i<4;i++)vailDataCode+=String.valueOf(code[random.nextInt(36)]);
        String str="尊敬的"+receiveMailAccount+"用户，您好！"+ "这里是您的验证码:"+vailDataCode;
        return str;
    }


    /**
     * 发送邮件
     * @param To
     */
    public void sendEmail(String To)throws MessagingException {
        setReceiveMailAccount(To);
        String text=setText();

        Properties properties = new Properties();
        properties.put("mail.transport.protocol", "smtp");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", 465);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.ssl.enable", "true");// 设置是否使用ssl安全连接
        properties.put("mail.debug", "false");// 设置是否显示debug信息

        Session session = Session.getInstance(properties);
        Message message = new MimeMessage(session);         //获取邮件对象
        message.setFrom(new InternetAddress(from));
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(receiveMailAccount));
        message.setSubject(subject);
        message.setText(text);
        Transport transport = session.getTransport();
        transport.connect("2501059603@qq.com", "wuervgglirwgdjgg");
        transport.sendMessage(message, message.getAllRecipients());
        transport.close();
    }

}
