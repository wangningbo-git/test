package main.java.com.Zhao.dao.mapper;

public interface AdminMapper {
    public String findByAdminName(String adminName,String adMinPasswod);       //查询admin账号和密码是否正确;正确返回主键，错误返回字符串NULL
}
