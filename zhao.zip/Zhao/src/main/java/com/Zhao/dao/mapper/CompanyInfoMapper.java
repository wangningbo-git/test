package main.java.com.Zhao.dao.mapper;

import main.java.com.Zhao.dao.entity.CompanyInfo;

public interface CompanyInfoMapper {
    public String findByAccount(String email,String password);      //通过邮箱账号，查询账号密码是否正确;返回主键
    public void insertCompanyInfo(CompanyInfo company);         //插入公司数据
}
