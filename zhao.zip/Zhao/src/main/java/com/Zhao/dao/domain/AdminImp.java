package main.java.com.Zhao.dao.domain;

import main.java.com.Zhao.common.ConnUtils;
import main.java.com.Zhao.dao.mapper.AdminMapper;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AdminImp implements AdminMapper {

    private Connection connection;

    public AdminImp(){
        ConnUtils connUtils=new ConnUtils();
        if(connection==null) {
            try {
                connection=connUtils.getConn();
            } catch (NamingException e) { e.printStackTrace(); }
            catch (SQLException throwables) { throwables.printStackTrace(); }
        }
    }

    @Override
    public String findByAdminName(String adminName, String adMinPasswod) {
        String str="NULL";
        try {
            Statement statement=connection.createStatement();
            String sql="select admin_name from admin where admin_name=\""+adminName+"\" and admin_password=\""+adMinPasswod+"\"";
            ResultSet resultSet=statement.executeQuery(sql);
            if(resultSet.next()){
                str=resultSet.getString("admin_name");
            }
        }catch (SQLException e){e.printStackTrace();}
        return str;
    }

}
