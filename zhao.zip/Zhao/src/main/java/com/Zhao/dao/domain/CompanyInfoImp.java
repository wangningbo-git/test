package main.java.com.Zhao.dao.domain;

import main.java.com.Zhao.common.ConnUtils;
import main.java.com.Zhao.dao.entity.CompanyInfo;
import main.java.com.Zhao.dao.mapper.CompanyInfoMapper;

import javax.naming.NamingException;
import java.sql.*;

public class CompanyInfoImp implements CompanyInfoMapper {
    private Connection connection;

    public CompanyInfoImp(){
        ConnUtils connUtils=new ConnUtils();
        if(connection==null) {
            try {
                connection=connUtils.getConn();
            } catch (NamingException e) { e.printStackTrace(); }
            catch (SQLException throwables) { throwables.printStackTrace(); }
        }
    }

    @Override
    public String findByAccount(String email, String password) {
        String companyId="NULL";
        try {
            Statement statement=connection.createStatement();
            String sql="select company_id from companyinfo where company_account=\""+email+"\" and company_password=\""+password+"\"";
            ResultSet resultSet=statement.executeQuery(sql);
            if(resultSet.next()){
                companyId=resultSet.getString("company_id");
            }
        }catch (SQLException e){e.printStackTrace();}
        return companyId;
    }

    @Override
    public void insertCompanyInfo(CompanyInfo company) {
        try{
            Statement statement=connection.createStatement();
            String sql="insert into companyinfo values(?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setString(1,company.getCompanyId());
            preparedStatement.setInt(2,company.getCompanyStatus());
            preparedStatement.setString(3,company.getCompanyAccount());
            preparedStatement.setString(4,company.getCompanyPassword());
            preparedStatement.setString(5,company.getCompanyName());
            preparedStatement.setString(6,company.getCompanyTel());
            preparedStatement.setString(7,company.getCompanyEmail());
            preparedStatement.setString(8,company.getCompanyAddress());
            preparedStatement.setString(9,company.getCompanyAddInfo());
            java.sql.Date sqlDate=new java.sql.Date(company.getRegisterTime().getTime());  //java日期类型转sql类型Date
            preparedStatement.setDate(10,sqlDate);
            preparedStatement.executeUpdate();
        }catch (SQLException e){e.printStackTrace();}
    }

}
