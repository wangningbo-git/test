package main.java.com.Zhao.dao.mapper;

import main.java.com.Zhao.dao.entity.UserInfo;

public interface UserInfoMapper {
    public String findByAccount(String email,String password);      //通过邮箱账号，查询账号密码是否正确;返回主键
    public void insertUser(UserInfo user);              //插入user信息

}
