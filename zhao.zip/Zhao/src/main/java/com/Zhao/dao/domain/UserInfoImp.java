package main.java.com.Zhao.dao.domain;

import main.java.com.Zhao.common.ConnUtils;
import main.java.com.Zhao.dao.entity.UserInfo;
import main.java.com.Zhao.dao.mapper.UserInfoMapper;
import javax.naming.NamingException;
import java.sql.*;

public class UserInfoImp implements UserInfoMapper {
    private Connection connection;

    public UserInfoImp(){
        ConnUtils connUtils=new ConnUtils();
        if(connection==null) {
            try {
                connection=connUtils.getConn();
            } catch (NamingException e) { e.printStackTrace(); }
            catch (SQLException throwables) { throwables.printStackTrace(); }
        }
    }

    @Override
    public String findByAccount(String email,String password){
        String userId="NULL";
        try {
            Statement statement=connection.createStatement();
            String sql="select user_id from userinfo where user_account=\""+email+"\" and user_password=\""+password+"\"";
            ResultSet resultSet=statement.executeQuery(sql);
            if(resultSet.next()){
                userId=resultSet.getString("user_id");
            }
        }catch (SQLException e){e.printStackTrace();}
        return userId;
    }

    @Override
    public void insertUser(UserInfo user) {
        try {
            Statement statement=connection.createStatement();
            String sql="insert into userinfo values(?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setString(1,user.getUserId());
            preparedStatement.setString(2,user.getUserName());
            preparedStatement.setString(3,user.getUserAccount());
            preparedStatement.setString(4,user.getUserPassword());
            preparedStatement.setInt(5,user.getUserAge());
            preparedStatement.setString(6,user.getUserSex());
            preparedStatement.setString(7,user.getUserEducation());
            preparedStatement.setString(8,user.getUserEmail());
            preparedStatement.setString(9,user.getUserTel());
            preparedStatement.setString(10,user.getUserAddress());
            preparedStatement.setString(11,user.getUserAddInfo());
            java.sql.Date sqlDate=new java.sql.Date(user.getRegisterTime().getTime());  //java日期类型转sql类型Date
            preparedStatement.setDate(12,sqlDate);
            preparedStatement.executeUpdate();
        }catch (SQLException e){e.printStackTrace();}
    }

}
