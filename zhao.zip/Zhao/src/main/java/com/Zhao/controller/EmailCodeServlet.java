package main.java.com.Zhao.controller;

import main.java.com.Zhao.service.EmailUnit;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "EmailCodeServlet",urlPatterns = "/sendEmailCode.do")
public class EmailCodeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        String emailAccount = request.getParameter("emailAccount");
        if (emailAccount == null) {
            out.write("{\"status\":0}");        //像前端返回json字符串；0代表没有正常接收到目标邮箱账号
        } else {
            try{
                EmailUnit emailUnit = new EmailUnit();
                emailUnit.sendEmail(emailAccount);
                request.getSession().setAttribute("trueEmailVailDataCode",emailUnit.getVailDataCode());
                out.write("{\"status\":1}");        //1代表发送成功
            }catch (MessagingException e){out.write("{\"status\":-1}");}        //-1代表发送失败
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

}
