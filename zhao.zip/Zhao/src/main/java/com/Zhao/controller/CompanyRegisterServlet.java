package main.java.com.Zhao.controller;

import main.java.com.Zhao.dao.entity.CompanyInfo;
import main.java.com.Zhao.service.DBService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.UUID;

@WebServlet(name = "CompanyRegisterServlet")
public class CompanyRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        request.setCharacterEncoding("utf-8");
        String emailVailCode = (String) request.getSession().getAttribute("trueEmailVailDataCode");
        emailVailCode=emailVailCode.toLowerCase();
        String inputVailCode = request.getParameter("emailVailDataCode").toLowerCase();
        if (!emailVailCode.equals(inputVailCode)) {         //检测验证码是否输入正确
            out.write("{\"status\":0}");        //0代表验证码错误
        }else {
            CompanyInfo companyInfo=new CompanyInfo();
            companyInfo.setCompanyId(UUID.randomUUID().toString().replace("-", ""));
            companyInfo.setCompanyStatus(0);
            companyInfo.setCompanyAccount(request.getParameter("emailAccount"));
            companyInfo.setCompanyPassword(request.getParameter("password"));
            companyInfo.setCompanyName(request.getParameter("companyName"));
            companyInfo.setCompanyTel(request.getParameter("tel"));
            companyInfo.setCompanyEmail(request.getParameter("connectEmail"));
            companyInfo.setCompanyAddress(request.getParameter("address"));
            companyInfo.setCompanyAddInfo(request.getParameter("addInfo"));
            companyInfo.setRegisterTime(new Date());
            DBService dbService=new DBService();
            dbService.insertCompany(companyInfo);
            out.write("{\"status\":1}");        //1代表注册成功
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
