package main.java.com.Zhao.controller;

import main.java.com.Zhao.service.DBService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "LoginServlet",urlPatterns = "/login/submit.do")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out=response.getWriter();
        String vailData=request.getParameter("vailData");
        String trueVailData=(String) request.getSession().getAttribute("VailDataCode");
        if(!vailData.equals(trueVailData)){
            out.write("{\"status\":0}");   //返回给前端Json，0代表验证码错误
            out.flush();
            out.close();
            return;
        }

        String account=request.getParameter("userName");
        String password=request.getParameter("password");
        String role=request.getParameter("role");
        DBService dbService=new DBService();
        String rs=dbService.findAccount(account,password,role);
        if(rs.equals("NULL"))out.write("{\"status\":-1}");          //-1代表账号或密码错误
        else{
            request.getSession().setAttribute("user_id",rs);    //验证成功，主键保存至session中
            out.write("{\"status\":1}");                //1代表账号密码正确
        }
        out.flush();
        out.close();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
