package main.java.com.Zhao.controller;

import main.java.com.Zhao.service.CreateVailDataCode;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 将验证码图片返回给前端页面
 */
@WebServlet(name = "VailDataImgServlet",urlPatterns = "/vailDataImg")
public class VailDataImgServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CreateVailDataCode createVaildataCode=new CreateVailDataCode();
        createVaildataCode.init();
        String str=createVaildataCode.getStr().toLowerCase();
        request.getSession().setAttribute("VailDataCode",str);
        BufferedImage image=createVaildataCode.getImage();
        try {
            response.setContentType("image/png");   //具体请求中的媒体类型信息
            OutputStream os = response.getOutputStream();
            ImageIO.write(image, "png", os);
            os.flush();
            os.close();
        }catch (IOException e){e.printStackTrace();}
    }

}
