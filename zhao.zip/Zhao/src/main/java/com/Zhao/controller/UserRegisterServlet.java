package main.java.com.Zhao.controller;

import main.java.com.Zhao.dao.entity.UserInfo;
import main.java.com.Zhao.service.DBService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.UUID;

@WebServlet(name = "UserRegisterServlet",urlPatterns = "/userRegister.do")
public class UserRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        request.setCharacterEncoding("utf-8");
        String emailVailCode = (String) request.getSession().getAttribute("trueEmailVailDataCode");
        emailVailCode=emailVailCode.toLowerCase();
        String inputVailCode = request.getParameter("emailVailDataCode").toLowerCase();
        if (!emailVailCode.equals(inputVailCode)) {         //检测验证码是否输入正确
            out.write("{\"status\":0}");        //0代表验证码错误
        } else {
            UserInfo user = new UserInfo();
            user.setUserId(UUID.randomUUID().toString().replace("-", ""));
            user.setUserName(request.getParameter("truename"));
            user.setUserAccount(request.getParameter("emailAccount"));
            user.setUserPassword(request.getParameter("password"));
            user.setUserAge(Integer.parseInt(request.getParameter("age")));
            user.setUserSex(request.getParameter("sex"));
            user.setUserEducation(request.getParameter("education"));
            user.setUserEmail(request.getParameter("connectEmail"));
            user.setUserTel(request.getParameter("tel"));
            user.setUserAddress(request.getParameter("address"));
            user.setUserAddInfo(request.getParameter("addInfo"));
            user.setRegisterTime(new Date());
            DBService dbService = new DBService();
            dbService.insertUser(user);
            out.write("{\"status\":1}");        //1代表注册成功
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
